import { Walkthrough } from '@/components/marketing/walkthrough';
import { FeatureStory } from '@/components/marketing/feature-story';
import { RevealEffects } from '@/components/marketing/reveal';
import { HeadlightReveal } from '@/components/marketing/headlight-reveal';
import { OrchestrationDemo } from '@/components/marketing/orchestration-demo';
import { ArrowDown, ArrowUpRight, ArrowRight, BatteryCharging, BriefcaseBusiness, Clock3, House, MapPin } from 'lucide-react';

export default function Home() {
  return (
    <main id="top">
      <RevealEffects />
      <a className="skip-link" href="#vision">Skip to content</a>
      <section className="hero" aria-labelledby="hero-title">
        <img className="hero-photo" src="/hero-road-cars-v3.png" alt="Cars traveling on a winding mountain road seen from above" fetchPriority="high" />
        <div className="hero-grain" aria-hidden="true" />
        <div className="hero-shade" />
        <header className="navigation">
          <a href="#top" className="brand" aria-label="Hyperfleets home"><img src="/hyperfleets-logo.png" alt="hyperfleets.ai" /></a>
          <nav aria-label="Main navigation"><a href="#vision">Our vision</a><a href="#walkthrough">How it works</a><a href="#approach">Our approach <ArrowUpRight size={15}/></a></nav>
        </header>
        <div className="hero-topline"><span className="eyebrow">Your car. A world of possibility.</span><span className="hero-index">01 — The road ahead</span></div>
        <div className="hero-bottom">
          <div className="hero-copy"><h1 id="hero-title">We make autonomous machines work together.</h1><p>Your car has places to be. Even when you don’t. We’re building the software that puts individually owned autonomous vehicles to work, on your terms.</p><a className="pill" href="#walkthrough">See how it works <span><ArrowUpRight size={23}/></span></a></div>
          <div className="hero-wordmark" aria-hidden="true">hyperfleets<span>.ai</span></div>
        </div>
        <a href="#vision" className="scroll-cue" aria-label="Scroll to our vision"><ArrowDown size={20}/></a>
      </section>
      <section id="vision" className="section vision">
        <div className="section-label"><span>01 / Our belief</span><span>A future worth connecting</span></div>
        <div className="belief-intro">
          <h2><span className="belief-primary">A car when you need it.</span><span>An earning asset when you don’t.</span></h2>
          <p className="belief-lead">Autonomous vehicles should be able to create value for their owners without giving up the freedom of personal ownership.</p>
        </div>
        <div className="belief-grid">
          <article><span>01</span><h3>Owned by you.</h3><p>Your Level 4 vehicle remains your asset. You decide when it is available and when it comes home.</p></article>
          <article><span>02</span><h3>Working by your rules.</h3><p>Battery reserve, geography, job types, mileage, and minimum earnings become hard constraints.</p></article>
          <article><span>03</span><h3>Optimized as one day.</h3><p>Hyperfleets plans jobs, charging, repositioning, and return time together—then manages the economics.</p></article>
        </div>
        <p className="belief-boundary">The certified autonomous-driving system remains responsible for driving and safety. Hyperfleets coordinates the work around it.</p>
      </section>
      <Walkthrough />
      <FeatureStory />
      <HeadlightReveal />
      <div className="light-zone">
      <section id="network" className="section network">
        <div className="section-label"><span>04 / One network, many possibilities</span><span>Many owners. One coordinated network.</span></div>
        <div className="section-heading"><h2>The right vehicle.<br/>The right work.</h2><p>We’re designing a common way to connect available vehicles, understand their limits, and assign the work they’re qualified to do.</p></div>
        <div className="network-flow" aria-label="Owners make vehicles available, Hyperfleets allocates work, businesses request capacity">
          <div className="flow-end"><span className="small-label">SUPPLY</span><h3>Independent owners</h3><p>Individual owners<br/>Fleet operators<br/>Leasing companies</p></div>
          <div className="flow-connector" aria-hidden="true"><ArrowRight size={22}/></div>
          <div className="flow-center"><img src="/hyperfleets-logo.png" alt="Hyperfleets"/><span>One orchestration layer</span></div>
          <div className="flow-connector" aria-hidden="true"><ArrowRight size={22}/></div>
          <div className="flow-end"><span className="small-label">DEMAND</span><h3>Work to be done</h3><p>Passenger transportation<br/>Delivery &amp; logistics<br/>Vehicle repositioning</p></div>
        </div>
        <div className="steps">
          <article><span className="step-number">01</span><h3>Owners set the terms.</h3><p>Availability, return times, operating areas, battery reserves, and permitted work. Every assignment begins with the owner’s constraints.</p></article>
          <article><span className="step-number">02</span><h3>The network finds the fit.</h3><p>Match demand with qualified capacity across fleets, balancing the job, the vehicle’s capabilities, and the economics.</p></article>
          <article><span className="step-number">03</span><h3>The vehicle gets to work.</h3><p>An authorized mission is sent to the vehicle’s certified autonomous-driving system, which remains responsible for driving.</p></article>
        </div>
      </section>
      <OrchestrationDemo />
      <section className="section usecases">
        <div className="section-heading"><h2>One car.<br/>More ways to work.</h2><p>Different jobs. The same principle: find the right use of an available vehicle, within its owner’s rules.</p></div>
        <div className="usecase-grid"><article className="usecase"><span>01 / MOVE PEOPLE</span><h3>A ride across town.</h3><p>Match available time with qualified passenger trips inside the vehicle’s operating area.</p></article><article className="usecase"><span>02 / MOVE GOODS</span><h3>The last mile, covered.</h3><p>Connect delivery demand with vehicles that have the right capacity and permissions.</p></article><article className="usecase"><span>03 / MAKE THE NEXT MOVE</span><h3>Be where the work is.</h3><p>Balance repositioning and charging with the value of the next opportunity.</p></article></div>
      </section>
      <section className="section capability-bento" aria-labelledby="capability-title">
        <div className="bento-heading"><span className="small-label">THE SYSTEM AT WORK</span><h2 id="capability-title">One plan.<br/>Every moving part.</h2><p>Clear examples of how an owner’s preferences become a coordinated day for the vehicle.</p></div>
        <div className="bento-grid">
          <article className="bento-card bento-photo-card"><img src="/hero-road-cars-v3.png" alt="Several cars traveling on a winding road" loading="lazy"/><div><BriefcaseBusiness size={18}/><span>Work allocation</span><h3>Match the vehicle to the right opportunity.</h3></div></article>
          <article className="bento-card bento-rule-card"><div className="bento-card-title"><Clock3 size={18}/><span>Owner schedule</span></div><h3>Available until 5:00 PM</h3><div className="schedule-track"><i/><span>9 AM</span><strong>8 hours available</strong><span>5 PM</span></div><small>Return-home time stays protected.</small></article>
          <article className="bento-card bento-map-card"><div className="bento-card-title"><MapPin size={18}/><span>Network position</span></div><h3>Move closer to tomorrow’s demand.</h3><div className="mini-map" aria-hidden="true"><i/><i/><i/><i/><span><MapPin size={20}/></span></div></article>
          <article className="bento-card bento-energy-card"><div className="bento-card-title"><BatteryCharging size={18}/><span>Energy plan</span></div><div className="battery-ring"><strong>72%</strong><span>ready</span></div><h3>Charge when time and price make sense.</h3></article>
          <article className="bento-card bento-home-card"><div className="bento-card-title"><House size={18}/><span>Return plan</span></div><div className="arrival-card"><small>PLANNED ARRIVAL</small><strong>4:44 PM</strong><span>16 minutes early</span></div><h3>Ready before you are.</h3></article>
        </div>
      </section>
      <section className="possibility" aria-labelledby="possibility-heading">
        <div className="possibility-image"><img src="/charging.jpg" alt="An electric vehicle connected to a charging station" loading="lazy"/><span>Built around the road ahead.</span></div>
        <div className="possibility-copy"><span className="small-label">THE LONG-TERM POSSIBILITY</span><h2 id="possibility-heading">Your vehicle.<br/>Your terms.<br/><span>More possibility.</span></h2><blockquote>“I don’t need my car from 9 until 5. Put it to work and have it back before I leave.”</blockquote><p>That’s the future we’re working toward: independently owned autonomous vehicles becoming part of something larger, while owners stay in control.</p></div>
      </section>
      </div>
      <div className="dark-return">
      <section id="approach" className="section approach">
        <div className="section-label"><span>05 / Our approach</span><span>Neutral by design</span></div>
        <div className="section-heading"><h2>A shared network.<br/>An independent future.</h2><p>The value is in connecting capacity across manufacturers, driving systems, and owners. We’re building for that diversity from the start.</p></div>
        <div className="approach-rows">
          <article><span>01</span><h3>Above the driving layer.</h3><p>Our focus is interoperability, allocation, and economics. The certified autonomous-driving system handles the driving.</p></article>
          <article><span>02</span><h3>Built around the owner.</h3><p>Availability, return time, battery reserve, geographic limits, permitted jobs, and minimum earnings belong to the owner. Our software works within them.</p></article>
          <article><span>03</span><h3>Built for the next step.</h3><p>We’re building the scheduling, owner policies, simulation, and mission infrastructure for a future where L4 platforms support authorized third-party missions.</p></article>
        </div>
      </section>
      <footer className="footer-wrap">
        <div className="footer-card">
          <div className="footer-lead"><a href="#top" className="footer-brand" aria-label="Hyperfleets home"><img src="/hyperfleets-logo.png" alt="hyperfleets.ai"/></a><p>We make autonomous machines work together.</p></div>
          <div className="footer-links">
            <div><strong>Explore</strong><a href="#vision">Our belief</a><a href="#walkthrough">How it works</a><a href="#owner-controls">Owner controls</a></div>
            <div><strong>System</strong><a href="#network">The network</a><a href="#decision-heading">Daily orchestration</a><a href="#approach">Our approach</a></div>
            <div><strong>Principles</strong><span>Owner controlled</span><span>Driving-layer neutral</span><span>Economically optimized</span></div>
          </div>
          <div className="footer-bottom"><span>© 2026 Hyperfleets. All rights reserved.</span><a className="back-top" href="#top">Back to top <ArrowUpRight size={18}/></a></div>
        </div>
      </footer>
      </div>
    </main>
  );
}
