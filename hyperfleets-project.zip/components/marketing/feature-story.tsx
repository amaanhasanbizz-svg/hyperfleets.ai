'use client';
import { useState } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { Clock3, BriefcaseBusiness, BatteryCharging, House, Check, ArrowUpRight } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
const features = [
  {id:'rules',icon:Clock3,title:'Starts with your rules.',description:'Set when your car is available, where it can go, the work it can do, and the earnings that make it worthwhile.',label:'Owner policy',heading:'Your car. Your boundaries.',image:'/vehicle-hero.jpg',caption:'Available on your schedule',rows:[['Available','9:00 AM – 5:00 PM'],['Minimum battery','30%'],['Operating area','Within 15 miles'],['Allowed work','Rides & deliveries'],['Minimum daily earnings','$75']],foot:'Example owner preferences'},
  {id:'work',icon:BriefcaseBusiness,title:'Finds work worth doing.',description:'Evaluate available jobs against your preferences, time, energy, and operating costs. Every decision should make economic sense.',label:'Work allocation',heading:'The best fit comes first.',image:'/hero-road-cars-v3.png',caption:'Qualified work, ranked by value',rows:[['Delivery nearby','Eligible'],['Passenger pickup','Eligible'],['Outside your area','Excluded'],['Below your minimum','Excluded']],foot:'Illustrative matching logic'},
  {id:'energy',icon:BatteryCharging,title:'Knows when to recharge.',description:'Plan charging and repositioning around the next job, expected demand, and the battery reserve you want to keep.',label:'Energy & positioning',heading:'Plan beyond the next trip.',image:'/charging.jpg',caption:'Charge before the next demand window',rows:[['Current battery','42%'],['Owner reserve','30%'],['Next action','Charge before next job'],['After charging','Reposition near demand']],foot:'Example planning scenario'},
  {id:'home',icon:House,title:'Makes time to come home.',description:'Work fits around your life. Your return time shapes the schedule, including when to stop taking new jobs.',label:'Return planning',heading:'Ready when you need it.',image:'/hero.jpg',caption:'Home before you need it',rows:[['Required return','5:00 PM'],['Planned arrival','4:45 PM'],['Time buffer','15 minutes'],['Late-running jobs','Excluded']],foot:'Illustrative schedule, not a service guarantee'},
];
export function FeatureStory() {
 const [selected,setSelected] = useState('rules');
 const reduced = useReducedMotion();
 return <section id="owner-controls" className="section feature-section">
   <div className="section-label"><span>03 / The owner stays in control</span><span>Your priorities, built into every decision</span></div>
   <h2>Your car can do more.<br/><span>You still call the shots.</span></h2>
   <Tabs value={selected} onValueChange={(value) => setSelected(String(value))} orientation="vertical" className="feature-tabs">
     <TabsList className="feature-list" aria-label="Explore owner controls" aria-orientation="vertical" variant="line" onKeyDown={(event) => {
       if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return;
       event.preventDefault();
       const tabs = Array.from(event.currentTarget.querySelectorAll<HTMLButtonElement>('[role="tab"]'));
       const current = tabs.indexOf(document.activeElement as HTMLButtonElement);
       const next = tabs[(current + (event.key === 'ArrowDown' ? 1 : -1) + tabs.length) % tabs.length];
       next?.focus(); next?.click();
     }}>{features.map((feature) => {const Icon=feature.icon;return <TabsTrigger key={feature.id} value={feature.id} className="feature-trigger"><span className="feature-title"><Icon size={20}/>{feature.title}<ArrowUpRight size={18}/></span><span className="feature-description">{feature.description}</span></TabsTrigger>;})}</TabsList>
     <div className="feature-visual"><div className="feature-grid-paper" aria-hidden="true" />
       {features.map(feature => <TabsContent key={feature.id} value={feature.id} className="feature-panel"><AnimatePresence mode="wait"><motion.div key={selected} initial={reduced ? false : {opacity:0,y:12}} animate={{opacity:1,y:0}} transition={{duration:.3}} className="feature-stage"><figure className="feature-example-image"><img src={feature.image} alt="" loading="lazy"/><figcaption>{feature.caption}</figcaption></figure><div className="policy-card"><span className="policy-label">{feature.label}<span className="status-dot"/></span><h3>{feature.heading}</h3><dl>{feature.rows.map(([label,value]) => <div key={label}><dt>{label}</dt><dd>{value}{value==='Eligible' && <Check size={14}/>}</dd></div>)}</dl><span className="policy-foot">{feature.foot}</span></div></motion.div></AnimatePresence></TabsContent>)}
     </div>
   </Tabs>
 </section>;
}
